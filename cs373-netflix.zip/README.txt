Project #3: Netflix
Date: Wed, 10 Oct 2012

Course Name: CS 373
Unique: 53075

First Name: Raul
Last Name: Cardenas
EID: ruc63
E-mail: rucardenas@utexas.edu
Estimated number of hours: 10
Actual number of hours: 12

Partner First Name: Raul	
Partner Last Name: Bezerra Barbosa
Partner EID: rb35468
Partner E-mail: raulbbarbosa@gmail.com
Partner Estimated number of hours: 16 hours
Partner Actual number of hours: 12  

Turnin CS Username: rulises
GitHub ID: rulises
GitHub Repository Name: cs373-netflix

Comments:

----------------
Pair Programming
----------------

I attest to that fact that, of the time spent working on this project,
at least seventy-five (75) percent was spent working with the person
listed above in pair programming.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
